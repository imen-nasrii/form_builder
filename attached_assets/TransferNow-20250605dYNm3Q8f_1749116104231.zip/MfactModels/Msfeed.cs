﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Msfeed
    {
        public string? Parent { get; set; }
        public string? Child { get; set; }
    }

}
