﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class FAMILY
    {
        public string Family_No { get; set; }
        public string? Family { get; set; }
        public string? Sponsor { get; set; }
        public decimal? Hash { get; set; }
    }

}
