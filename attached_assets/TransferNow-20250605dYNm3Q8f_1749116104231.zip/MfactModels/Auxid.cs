﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class AuxId
    {
        public string? Auxid { get; set; }
        public string? Tkr { get; set; }
        public string? Unused { get; set; }
        public decimal? Hash { get; set; }
    }

}
