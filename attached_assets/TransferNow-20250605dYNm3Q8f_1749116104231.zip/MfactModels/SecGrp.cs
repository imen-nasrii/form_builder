﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Secgrp
    {
        public string secgrp { get; set; }
        public string? desc1 { get; set; }
        public string? desc2 { get; set; }
        public decimal? Hash { get; set; }

    }
}
