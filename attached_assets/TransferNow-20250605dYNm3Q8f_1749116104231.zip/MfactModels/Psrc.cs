﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Psrc
    {

        public string pSource { get; set;}
        public string? descr { get; set; }
        public string? Gis { get; set; }
        public decimal? Hash { get; set; }
    }

}
