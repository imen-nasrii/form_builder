﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Exchng
    {
        public string Exch { get; set; }
        public string? Exchange { get; set; }
        public string? Country { get; set; }
        public string? Tplus { get; set; }
        public decimal? Hash { get; set; }
    }
}
