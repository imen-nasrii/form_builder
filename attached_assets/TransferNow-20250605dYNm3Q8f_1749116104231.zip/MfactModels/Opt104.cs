﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Opt104
    {
        public string? Trxtyp { get; set; }
        public string? Lgdesc { get; set; }
        public string? Glxcat { get; set; }
        public string? Postyp { get; set; }
        public string? Class { get; set; }
        public string? PcrfField { get; set; }
        public decimal? Hash { get; set; }
    }

}
