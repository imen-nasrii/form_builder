﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Nrsro
    {
        public string nrsro { get; set; }
        public string? org_name { get; set; }
        public string? muller_id { get; set; }
        public string? idc_id { get; set; }
        public string? mrl_id { get; set; }
        public string? jjkenny_id { get; set; }
        public string? misc_id_1 { get; set; }
        public string? misc_id_2 { get; set; }
        public string? num_codes { get; set; }
        public string? rpt_col_id { get; set; }
        public string? rating_1 { get; set; }
        public string? rating_2 { get; set; }
        public string? rating_3 { get; set; }
        public string? rating_4 { get; set; }
        public string? rating_5 { get; set; }
        public string? rating_6 { get; set; }
        public string? rating_7 { get; set; }
        public string? rating_8 { get; set; }
        public string? rating_9 { get; set; }
        public string? rating_10 { get; set; }
        public string? rating_11 { get; set; }
        public string? rating_12 { get; set; }
        public string? rating_13 { get; set; }
        public string? rating_14 { get; set; }
        public string? rating_15 { get; set; }
        public string? rating_16 { get; set; }
        public string? rating_17 { get; set; }
        public string? rating_18 { get; set; }
        public string? rating_19 { get; set; }
        public string? rating_20 { get; set; }
        public string? rating_21 { get; set; }
        public string? rating_22 { get; set; }
        public string? rating_23 { get; set; }
        public string? rating_24 { get; set; }
        public string? rating_25 { get; set; }
        public string? rating_26 { get; set; }
        public string? rating_27 { get; set; }
        public string? rating_28 { get; set; }
        public string? rating_29 { get; set; }
        public string? rating_30 { get; set; }
        public string? unused { get; set; }
        public int? hash { get; set; }
    }

}
