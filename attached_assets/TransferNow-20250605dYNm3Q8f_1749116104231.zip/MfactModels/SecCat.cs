﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Seccat
    {
        public string seccat { get; set; }
        public string? descr { get; set; }
        public string? exclude { get; set; }
        public decimal? Hash { get; set; }
    }
}
