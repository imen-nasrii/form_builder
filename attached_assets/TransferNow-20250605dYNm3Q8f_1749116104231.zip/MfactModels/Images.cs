﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Images
    {
        public string? MenuId { get; set; }
        public byte[]? Custom { get; set; }
        public byte[]? Image { get; set; }
    }

}
