﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Reason
    {
        public string? descr { get; set; }
        public string reason { get; set; }
        public string? unused { get; set; }
        public decimal? hash { get; set; }

    }
}
