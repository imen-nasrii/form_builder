﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class IdxMas
    {
        public string? Findex { get; set; }
        public string? FindexDesc { get; set; }
        public string? Val_Time { get; set; }
        public decimal? Hash { get; set; }
    }

}
