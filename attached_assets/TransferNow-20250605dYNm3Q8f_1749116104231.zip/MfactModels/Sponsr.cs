﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Sponsr
    {
        public string sponsor_no { get; set; }
        public string? sponsor { get; set; }
        public string? hedgetek { get; set; }
        public decimal? hash { get; set; }
    }
}
