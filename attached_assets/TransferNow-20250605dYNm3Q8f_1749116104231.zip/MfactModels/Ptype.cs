﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Ptype
    {
        public string? psource { get; set; }
        public string? ptype { get; set; }
        public string? descr { get; set; }
        public string? time { get; set; }
        public int? hash { get; set; }
    }
}
