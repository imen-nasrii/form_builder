﻿namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Falias
    {
        public string Aliasname { get; set; }
        public string? Descr { get; set; }
        public string? User_id { get; set; }
        public string? Criteria { get; set; }
    }
}
