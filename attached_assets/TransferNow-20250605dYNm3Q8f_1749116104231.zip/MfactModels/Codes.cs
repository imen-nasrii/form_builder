﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Codes
    {
        public string code { get; set; }
        public string id { get; set; }
        public string? desc1 { get; set; }
        public string? id2 { get; set; }
        public decimal? hash { get; set; }
    }
}
