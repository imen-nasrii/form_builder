﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class Shrgrp
    {
        public string fund { get; set; }
        public string shrgrp { get; set; }
        public string Class { get; set; }
        public string? inactive { get; set; }
    }
}
