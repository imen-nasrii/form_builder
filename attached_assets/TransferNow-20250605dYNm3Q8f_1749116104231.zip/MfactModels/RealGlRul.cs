﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linedata.Mfact.Shared.Domain.MfactModels
{
    public class RealGlRul
    {
        public string? Fund { get; set; }
        public string? Guid { get; set; }
        public decimal? TotalGL { get; set; }
        public decimal? Hash { get; set; }
    }
}
